      <section class="section-md bg-transparent text-center">
        <div class="container">
          <div class="row justify-content-center text-center">
            <div class="col-xl-11">
              <h1 class="title-1">404</h1>
              <h3>Halaman tidak dapat ditampilkan :(</h3>
              <div class="btn-group-1"><a class="btn btn-lg btn-primary" href="<?php echo base_url(); ?>">Ke Home</a></div>
            </div>
          </div>
        </div>
      </section>